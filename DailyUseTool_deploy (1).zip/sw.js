/* Daily Use Tool — service worker (offline support).
   Change VER whenever you want every phone to drop its old cache. */
const VER = 'v1';
const SHELL = 'dut-shell-' + VER;
const RUNTIME = 'dut-rt-' + VER;
const CORE = ['./', 'index.html', 'manifest.webmanifest', 'icon-192.png', 'icon-512.png', 'apple-touch-icon.png'];
const LIBS = [
  'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/dist/umd/supabase.js',
  'https://cdnjs.cloudflare.com/ajax/libs/exceljs/4.4.0/exceljs.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/jsbarcode/3.11.5/JsBarcode.all.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js',
  'https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&display=swap'
];
const LIVE = /(supabase\.co|api\.anthropic\.com|open-meteo\.com|dictionaryapi\.dev|mymemory\.translated\.net|languagetool\.org|frankfurter\.app|nominatim\.openstreetmap\.org|weserv\.nl|tile\.openstreetmap\.org|google\.com\/search)/i;
const STATIC_CDN = /(cdn\.jsdelivr\.net|unpkg\.com|cdnjs\.cloudflare\.com|fonts\.googleapis\.com|fonts\.gstatic\.com)/i;

self.addEventListener('install', e => {
  e.waitUntil((async () => {
    const shell = await caches.open(SHELL);
    await Promise.allSettled(CORE.map(u => shell.add(u)));
    const rt = await caches.open(RUNTIME);
    await Promise.allSettled(LIBS.map(async u => { const r = await fetch(u, { mode: 'no-cors' }); await rt.put(u, r); }));
    self.skipWaiting();
  })());
});

self.addEventListener('activate', e => {
  e.waitUntil((async () => {
    const keep = [SHELL, RUNTIME];
    for (const k of await caches.keys()) if (k.startsWith('dut-') && !keep.includes(k)) await caches.delete(k);
    await self.clients.claim();
  })());
});

self.addEventListener('message', e => { if (e.data === 'skipWaiting') self.skipWaiting(); });

async function networkFirst(req, cacheName, fallbackKey) {
  const cache = await caches.open(cacheName);
  try {
    const ctrl = new AbortController(); const t = setTimeout(() => ctrl.abort(), 5000);
    const res = await fetch(req, { signal: ctrl.signal }); clearTimeout(t);
    if (res && res.ok) cache.put(fallbackKey || req, res.clone());
    return res;
  } catch (err) {
    const hit = await cache.match(fallbackKey || req, { ignoreSearch: true }) || await caches.match('index.html') || await caches.match('./');
    if (hit) return hit;
    throw err;
  }
}

async function cacheFirst(req) {
  const cache = await caches.open(RUNTIME);
  const hit = await cache.match(req);
  if (hit) return hit;
  const res = await fetch(req);
  if (res && (res.ok || res.type === 'opaque')) cache.put(req, res.clone());
  return res;
}

self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (LIVE.test(url.href)) return;                                   // live data: always network
  if (req.mode === 'navigate') { e.respondWith(networkFirst(req, SHELL, 'index.html')); return; }
  if (url.origin === self.location.origin) { e.respondWith(networkFirst(req, SHELL)); return; }
  if (STATIC_CDN.test(url.hostname)) { e.respondWith(cacheFirst(req)); return; }
});
